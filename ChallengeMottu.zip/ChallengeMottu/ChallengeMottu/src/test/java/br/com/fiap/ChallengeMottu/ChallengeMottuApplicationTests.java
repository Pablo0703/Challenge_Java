package br.com.fiap.ChallengeMottu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeMottuApplicationTests {

	@Test
	void contextLoads() {
	}

}
