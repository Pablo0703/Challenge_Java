package br.com.fiap.ChallengeMottu.Repository;

import br.com.fiap.ChallengeMottu.Entity.LocalizacaoMotoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocalizacaoMotoRepository extends JpaRepository<LocalizacaoMotoEntity, Long> {
}
