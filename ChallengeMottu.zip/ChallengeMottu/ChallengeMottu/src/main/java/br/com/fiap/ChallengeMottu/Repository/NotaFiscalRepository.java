package br.com.fiap.ChallengeMottu.Repository;

import br.com.fiap.ChallengeMottu.Entity.NotaFiscalEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotaFiscalRepository extends JpaRepository<NotaFiscalEntity, Long> {
}
