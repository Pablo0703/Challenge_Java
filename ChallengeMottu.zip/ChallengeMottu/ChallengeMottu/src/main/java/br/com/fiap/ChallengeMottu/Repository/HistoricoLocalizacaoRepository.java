package br.com.fiap.ChallengeMottu.Repository;

import br.com.fiap.ChallengeMottu.Entity.HistoricoLocalizacaoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistoricoLocalizacaoRepository extends JpaRepository<HistoricoLocalizacaoEntity, Long> {
}
