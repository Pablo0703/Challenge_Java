package br.com.fiap.ChallengeMottu.Repository;

import br.com.fiap.ChallengeMottu.Entity.StatusOperacaoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatusOperacaoRepository extends JpaRepository<StatusOperacaoEntity, Long> {
}
