package br.com.fiap.ChallengeMottu.Repository;

import br.com.fiap.ChallengeMottu.Entity.PatioEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatioRepository extends JpaRepository<PatioEntity, Long> {
}
